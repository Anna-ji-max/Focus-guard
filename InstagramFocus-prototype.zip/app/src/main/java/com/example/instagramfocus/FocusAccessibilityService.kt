package com.example.instagramfocus

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.graphics.Rect
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.FrameLayout
import android.widget.TextView
import kotlin.math.max

class FocusAccessibilityService : AccessibilityService() {

    private val instagramPackage = "com.instagram.android"
    private var bottomOverlay: FocusOverlay? = null
    private var reelOverlay: FocusOverlay? = null
    private var lastReelState = false

    private val quotePool = listOf(
        "You don't need to consume everything you're offered.",
        "Use Instagram. Don't let Instagram use your time.",
        "If you came for someone, go to them. Don't wander.",
        "One intentional action is enough.",
        "Your attention is yours.",
        "You can leave the feed whenever you want."
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        serviceInfo = serviceInfo.apply {
            flags = flags or AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        val pkg = event.packageName?.toString()
        if (pkg != instagramPackage) {
            removeOverlays()
            return
        }

        val root = rootInActiveWindow ?: return
        val isReels = detectSelectedReels(root)

        if (isReels != lastReelState) {
            lastReelState = isReels
            if (isReels) {
                showReelBlocker()
            } else {
                reelOverlay?.remove()
                reelOverlay = null
                showBottomBlocker(root)
            }
        } else if (!isReels) {
            showBottomBlocker(root)
        }
    }

    private fun detectSelectedReels(root: AccessibilityNodeInfo): Boolean {
        val nodes = ArrayList<AccessibilityNodeInfo>()
        collectNodes(root, nodes)

        for (n in nodes) {
            val label = listOfNotNull(
                n.text?.toString(),
                n.contentDescription?.toString()
            ).joinToString(" ").lowercase()

            // Prefer a selected/checked Reels navigation item.
            if (label.contains("reels") && (n.isSelected || n.isChecked)) return true

            // Some Instagram builds expose the selected tab through a parent.
            if (label == "reels") {
                var p = n.parent
                repeat(3) {
                    if (p != null && (p.isSelected || p.isChecked)) return true
                    p = p?.parent
                }
            }
        }
        return false
    }

    private fun collectNodes(node: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>) {
        out.add(node)
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectNodes(it, out) }
        }
    }

    private fun findNavigationBounds(root: AccessibilityNodeInfo): Rect {
        val screen = Rect()
        root.getBoundsInScreen(screen)

        // Fallback: bottom ~88dp. We use screen-relative positioning so different
        // phone sizes and navigation modes do not require hard-coded pixels.
        val bottomHeight = (88 * resources.displayMetrics.density).toInt()
        return Rect(screen.left, max(screen.bottom - bottomHeight, screen.top),
            screen.right, screen.bottom)
    }

    private fun showBottomBlocker(root: AccessibilityNodeInfo) {
        val bounds = findNavigationBounds(root)
        if (bottomOverlay == null) {
            bottomOverlay = FocusOverlay(this, fullScreen = false)
            bottomOverlay!!.setTouchBlocking(true)
            bottomOverlay!!.add()
        }
        bottomOverlay!!.updateBounds(bounds)
    }

    private fun showReelBlocker() {
        bottomOverlay?.remove()
        bottomOverlay = null

        if (reelOverlay == null) {
            reelOverlay = FocusOverlay(this, fullScreen = true)
            reelOverlay!!.setQuote(quotePool.random())
            reelOverlay!!.setTouchBlocking(true)
            reelOverlay!!.add()
        }
    }

    private fun removeOverlays() {
        bottomOverlay?.remove()
        reelOverlay?.remove()
        bottomOverlay = null
        reelOverlay = null
        lastReelState = false
    }

    override fun onInterrupt() {
        removeOverlays()
    }

    override fun onDestroy() {
        removeOverlays()
        super.onDestroy()
    }
}

private class FocusOverlay(
    private val service: AccessibilityService,
    private val fullScreen: Boolean
) {
    private val wm = service.getSystemService(WindowManager::class.java)
    private val container = FrameLayout(service)
    private val message = TextView(service)

    private var params: WindowManager.LayoutParams? = null

    init {
        val dark = (service.resources.configuration.uiMode and
                android.content.res.Configuration.UI_MODE_NIGHT_MASK) ==
                android.content.res.Configuration.UI_MODE_NIGHT_YES

        // Instagram-like empty-space colors.
        val background = if (dark) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        val primary = if (dark) 0xFFF5F5F5.toInt() else 0xFF262626.toInt()
        val secondary = if (dark) 0xFFA8A8A8.toInt() else 0xFF737373.toInt()

        container.setBackgroundColor(background)
        container.isClickable = true
        container.isFocusable = true

        message.textSize = if (fullScreen) 20f else 1f
        message.setTextColor(primary)
        message.gravity = Gravity.CENTER
        message.setPadding(40, 40, 40, 40)

        if (fullScreen) {
            container.addView(message, FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                Gravity.CENTER
            ))
        }
    }

    fun setQuote(text: String) {
        message.text = text
    }

    fun setTouchBlocking(block: Boolean) {
        container.isClickable = block
        container.isFocusable = block
        container.setOnTouchListener { _, _ -> block }
    }

    fun add() {
        val type = if (Build.VERSION.SDK_INT >= 22)
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY
        else
            @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_PHONE

        params = WindowManager.LayoutParams(
            if (fullScreen) WindowManager.LayoutParams.MATCH_PARENT else 1,
            if (fullScreen) WindowManager.LayoutParams.MATCH_PARENT else 1,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            android.graphics.PixelFormat.OPAQUE
        ).apply {
            gravity = Gravity.TOP or Gravity.START
        }

        // A focusable/touchable accessibility overlay needs its touch target to
        // consume input. We intentionally do not use FLAG_NOT_TOUCHABLE.
        params!!.flags = 0

        wm.addView(container, params)
    }

    fun updateBounds(bounds: Rect) {
        if (fullScreen) return
        params?.let {
            it.x = bounds.left
            it.y = bounds.top
            it.width = bounds.width()
            it.height = bounds.height()
            wm.updateViewLayout(container, it)
        }
    }

    fun remove() {
        try { wm.removeView(container) } catch (_: Exception) {}
    }
}

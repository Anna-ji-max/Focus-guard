package com.example.instagramfocus

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : android.app.Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 64, 48, 48)
        }

        val title = TextView(this).apply {
            text = "Instagram Focus"
            textSize = 30f
        }

        val body = TextView(this).apply {
            text = "\nUse Instagram without the endless recommendation loop.\n\n" +
                    "• Blocks the bottom recommendation/navigation area\n" +
                    "• Detects the Reels surface and covers it\n" +
                    "• Shows a short motivational message instead\n" +
                    "• Uses light/dark colors automatically\n\n" +
                    "This prototype uses Android AccessibilityService. " +
                    "Enable Instagram Focus in Android Accessibility settings."
            textSize = 17f
        }

        val button = Button(this).apply {
            text = "Enable Instagram Focus"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        root.addView(title)
        root.addView(body)
        root.addView(button)
        setContentView(root)
    }
}

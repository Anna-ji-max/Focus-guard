package com.example.focusguard

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

private const val IG = "com.instagram.android"

// Instagram's internal view IDs. They change between versions: check them with Android Studio's
// Layout Inspector or `adb shell uiautomator dump`, then edit here.
private val REEL_PLAYER_IDS = listOf("reel_recycler", "reel_player_page_container")
private const val TAB_BAR = "tab_bar"
private const val HOME_TAB = "feed_tab"
private const val SEARCH_TAB = "search_tab"
private const val REELS_TAB = "clips_tab"
private const val SEARCH_BOX = "action_bar_search_edit_text"

data class Colors(val bg: Int, val text: Int, val sub: Int, val accent: Int)

object Palette {
    private val LIGHT = Colors(0xFFFFFFFF.toInt(), 0xFF262626.toInt(), 0xFF737373.toInt(), 0xFF0095F6.toInt())
    private val DARK = Colors(0xFF000000.toInt(), 0xFFFAFAFA.toInt(), 0xFFA8A8A8.toInt(), 0xFF0095F6.toInt())

    /** Dark when the system is in night mode or Battery Saver is on, otherwise light. */
    fun now(c: Context): Colors {
        val night = (c.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        val saver = (c.getSystemService(Context.POWER_SERVICE) as PowerManager).isPowerSaveMode
        return if (night || saver) DARK else LIGHT
    }
}

object Quotes {
    val full = listOf(
        "You came here for a reason. Go do that.",
        "Your time is the one thing you can't scroll back.",
        "Be where your feet are.",
        "Close the feed. Open your day.",
        "Nothing here is as good as what you're about to do."
    )
    val tile = listOf("Focus", "Be here", "Not now", "Breathe")
}

class GuardService : AccessibilityService() {
    private val ui = Handler(Looper.getMainLooper())
    private lateinit var wm: WindowManager
    private val views = HashMap<String, View>()
    private val rects = HashMap<String, Rect>()
    private var pending = false

    override fun onServiceConnected() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.packageName == packageName || pending) return   // ignore our own overlays; throttle
        pending = true
        ui.postDelayed({ pending = false; evaluate() }, 40)
    }

    override fun onInterrupt() = hideAll()
    override fun onDestroy() { hideAll(); super.onDestroy() }

    private fun evaluate() {
        val root = rootInActiveWindow
        if (root == null || root.packageName != IG) { hideAll(); return }
        val screen = bounds(root)
        val bar = find(root, TAB_BAR)

        // 1) Reels tab is open: cover the whole Instagram window, bottom bar included.
        if (bar != null && REEL_PLAYER_IDS.any { find(root, it) != null }) {
            hide("region"); hide("tile")
            show("full", screen, Quotes.full.random(), 22f, back = true)
            return
        }
        hide("full")

        // 2) Explore grid: Search tab selected and search box idle. Keep the box usable for people search.
        val box = find(root, SEARCH_BOX)
        val idle = box == null || ((box.isShowingHintText || box.text.isNullOrEmpty()) && !box.isFocused)
        if (bar != null && find(root, SEARCH_TAB)?.isSelected == true && idle) {
            val top = if (box != null) bounds(box).bottom else screen.top + dp(112)
            show("region", Rect(screen.left, top, screen.right, bounds(bar).top), Quotes.full.random(), 18f)
        } else hide("region")

        // 3) Small quote tile exactly over the Reels tab button.
        val reelsTab = find(root, REELS_TAB)
        if (reelsTab != null) show("tile", bounds(reelsTab), Quotes.tile.random(), 9f) else hide("tile")
    }

    private fun find(root: AccessibilityNodeInfo, name: String): AccessibilityNodeInfo? =
        root.findAccessibilityNodeInfosByViewId("$IG:id/$name").firstOrNull { it.isVisibleToUser }

    private fun bounds(n: AccessibilityNodeInfo) = Rect().also { n.getBoundsInScreen(it) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun show(key: String, r: Rect, msg: String, sp: Float, back: Boolean = false) {
        val existing = views[key]
        try {
            if (existing != null) {
                if (rects[key] != r) wm.updateViewLayout(existing, params(r))
            } else {
                val v = build(msg, sp, back)
                wm.addView(v, params(r))
                views[key] = v
            }
            rects[key] = r
        } catch (_: Exception) { }
    }

    private fun hide(key: String) {
        rects.remove(key)
        views.remove(key)?.let { try { wm.removeView(it) } catch (_: Exception) { } }
    }

    private fun hideAll() = views.keys.toList().forEach { hide(it) }

    // No FLAG_NOT_TOUCHABLE: the overlay window owns every touch inside its rectangle,
    // so nothing underneath can be tapped or swiped.
    private fun params(r: Rect) = WindowManager.LayoutParams(
        r.width(), r.height(),
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
            WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
            WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.OPAQUE
    ).apply { gravity = Gravity.TOP or Gravity.START; x = r.left; y = r.top }

    private fun build(msg: String, sp: Float, back: Boolean): View {
        val c = Palette.now(this)
        val pad = dp(if (sp > 12f) 32 else 2)
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(c.bg)
            setPadding(pad, 0, pad, 0)
            isClickable = true
            setOnTouchListener { _, _ -> true }
            addView(TextView(context).apply {
                text = msg; textSize = sp; gravity = Gravity.CENTER; setTextColor(c.text)
            })
            if (back) addView(Button(context).apply {
                text = "Back to Home"; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt())
                background = GradientDrawable().apply { setColor(c.accent); cornerRadius = dp(8).toFloat() }
                setOnClickListener { goHome() }
            }, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(24) })
        }
    }

    private fun goHome() {
        val home = rootInActiveWindow?.let { find(it, HOME_TAB) }
        if (home?.performAction(AccessibilityNodeInfo.ACTION_CLICK) != true) performGlobalAction(GLOBAL_ACTION_BACK)
    }
}

package com.example.focusguard

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val c = Palette.now(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 120, 48, 48)
            setBackgroundColor(c.bg)
        }
        col.addView(TextView(this).apply { text = "FocusGuard"; textSize = 28f; setTextColor(c.text) })
        col.addView(TextView(this).apply {
            text = "\nTurn on FocusGuard under Accessibility > Installed apps, then open Instagram. " +
                "Reels, the Explore grid and the Reels tab will be covered."
            textSize = 15f; setTextColor(c.sub)
        })
        col.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        setContentView(col)
    }
}
